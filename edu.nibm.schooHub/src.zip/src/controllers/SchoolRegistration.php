<?php
// Assuming you have a separate file for database connection
global $conn;
require_once "../models/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate inputs
    $schoolName = trim($_POST['schoolName']);
    $location = trim($_POST['location']);
    $establishmentYear = trim($_POST['establishmentYear']);
    $logo = $_FILES['schoolLogo'];

    // Basic validation (You should expand upon this with more comprehensive checks)
    if (empty($schoolName) || empty($location) || empty($establishmentYear) || !is_numeric($establishmentYear)) {
        die("Invalid input.");
    }

    // Validate establishment year range
    if ($establishmentYear < 1800 || $establishmentYear > 2100) {
        die("Invalid establishment year.");
    }

    // Process logo upload if a file was uploaded
    if ($logo['error'] == UPLOAD_ERR_OK) {
        // Check file size, type, etc., here
        // For simplicity, we're skipping those checks

        // Read the file's content
        $logoData = file_get_contents($logo['tmp_name']);
    } else {
        // Handle cases where no logo was uploaded or there was an error
        $logoData = null;
    }

    // Insert into database
    try {
        $query = "INSERT INTO schools (name, location, establishment_year, logo) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssis", $schoolName, $location, $establishmentYear, $logoData);

        if ($stmt->execute()) {
            header("Location: ../views/Login.html");
            exit;
        } else {
            echo "Error: " . $stmt->error;
        }


    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    // Not a POST request
    echo "Invalid request.";
}
?>
