<?php
session_start();

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../views/Login.html");
    exit;
}

$userRole = isset($_SESSION['role']) ? $_SESSION['role'] : 'guest'; 
$userName = isset($_SESSION['name']) ? $_SESSION['name'] : 'Guest';


