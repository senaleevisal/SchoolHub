<?php

// Assuming you have a database connection established

// Query to fetch users
$query = "SELECT * FROM users";
$result = mysqli_query($connection, $query);

// Check if the query was successful
if ($result) {
    // Fetch all rows as an associative array
    $users = mysqli_fetch_all($result, MYSQLI_ASSOC);

    // Loop through the users and do something with each user
    foreach ($users as $user) {
        // Access user data using $user['column_name']
        $userId = $user['id'];
        $username = $user['username'];
        $email = $user['email'];

        // Do something with the user data
        echo "User ID: $userId, Username: $username, Email: $email" . PHP_EOL;
    }
} else {
    // Handle query error
    echo "Error: " . mysqli_error($connection);
}

// Close the database connection
mysqli_close($connection);